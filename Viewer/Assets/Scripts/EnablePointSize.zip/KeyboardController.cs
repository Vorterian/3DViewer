﻿using System.IO;
using UnityEngine;
using System.Collections;

public class KeyboardController : MonoBehaviour
{


    public Transform ZuDrehendesGameObject;
    public DataSingleton _datenAblage;

    private int _bewegungsGeschwindigkeit = 5000;
    private int _rotationsGeschwindigkeit = 10;

    public float distance = 5.0f;
    public float xSpeed = 120.0f;
    public float ySpeed = 120.0f;

    public float yMinLimit = -20f;
    public float yMaxLimit = 80f;

    public float distanceMin = .5f;
    public float distanceMax = 15f;

    public ModellViewer mV;


    float x = 0.0f;
    float y = 0.0f;



    private void Start()
    {
        Vector3 angles = transform.eulerAngles;
        x = angles.y;
        y = angles.x;

    }



    void Update()
    {
   
        // Pfeiltasten

        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.Translate(new Vector3(_bewegungsGeschwindigkeit * Time.deltaTime, 0, 0));
        }


        if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.Translate(new Vector3(-_bewegungsGeschwindigkeit * Time.deltaTime, 0, 0));
        }


        if (Input.GetKey(KeyCode.DownArrow))
        {
            transform.Translate(new Vector3(0, -_bewegungsGeschwindigkeit * Time.deltaTime, 0));
        }


        if (Input.GetKey(KeyCode.UpArrow))
        {
            transform.Translate(new Vector3(0, _bewegungsGeschwindigkeit * Time.deltaTime, 0));
        }


        // QWEASD
        if (Input.GetKey(KeyCode.W))
        {
            

            transform.Rotate(-Vector3.right * _rotationsGeschwindigkeit * Time.deltaTime);
            transform.Translate(new Vector3(0, -_bewegungsGeschwindigkeit * Time.deltaTime, 0));



        }

        if (Input.GetKey(KeyCode.S))
        {


            transform.Rotate(-Vector3.left * _rotationsGeschwindigkeit * Time.deltaTime);
            transform.Translate(new Vector3(0, _bewegungsGeschwindigkeit * Time.deltaTime, 0));

        }

        if (Input.GetKey(KeyCode.Q))
        {


            transform.Rotate(Vector3.forward * _rotationsGeschwindigkeit * Time.deltaTime);


        }

        if (Input.GetKey(KeyCode.E))
        {

            transform.Rotate(Vector3.back * _rotationsGeschwindigkeit * Time.deltaTime);

        }


        if (Input.GetKey(KeyCode.A))
        {

            transform.RotateAround(ZuDrehendesGameObject.position, Vector3.forward, _rotationsGeschwindigkeit * Time.deltaTime);

        }

        if (Input.GetKey(KeyCode.D))
        {


            // transform.position = new Vector3(transform.position.x + _rotationsGeschwindigkeit, transform.position.y , transform.position.z);
            //transform.RotateAround(ZuDrehendesGameObject.position, Vector3.back, -Input.GetAxis("Horizontal") * 135 * Time.deltaTime);
            transform.RotateAround(ZuDrehendesGameObject.position, Vector3.back, _rotationsGeschwindigkeit * Time.deltaTime);


        }

        if (Input.GetKey(KeyCode.Space))
        {


            transform.LookAt(ZuDrehendesGameObject.position);

        }
    }
}