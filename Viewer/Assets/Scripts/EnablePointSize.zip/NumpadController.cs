﻿using System.IO;
using UnityEngine;
using System.Collections;

public class NumpadController : MonoBehaviour
{


    public Transform ZuDrehendesGameObject;
    public DataSingleton _datenAblage;
    public ModellViewer mV;




    private void Start()
    {
    }



    void Update()
    {
   
        // Keypad

        if (Input.GetKey(KeyCode.KeypadMinus))
        {
            Vector3 scale = ZuDrehendesGameObject.localScale;
            Vector3 scaleNew = new Vector3(scale.x, scale.y, scale.z-1);
            ZuDrehendesGameObject.localScale = scaleNew;
        }



        if (Input.GetKey(KeyCode.KeypadPlus))
        {
            Vector3 scale = ZuDrehendesGameObject.localScale;
            Vector3 scaleNew = new Vector3(scale.x, scale.y, scale.z + 1);
            ZuDrehendesGameObject.localScale = scaleNew;
        }

    }
}